from qiskit.quantum_info import Statevector
import numpy as np

from classical_shadows import ShadowFinder
from classical_shadows.classical_shadow import estimate_observable, real_fidelity

np.random.seed(42)
np.set_printoptions(precision=2)

def create_random_mat(size, decimals=3):
    return np.round(np.random.normal(size=size) + 1j * np.random.normal(size=size), decimals)

n_qubit = 3
vec_A = create_random_mat(2**n_qubit)
vec_A /= np.linalg.norm(vec_A)  # Normalize the state vector
state_A = Statevector(vec_A)

vec_B = vec_A * (1+create_random_mat(2**n_qubit)/5)
vec_B /= np.linalg.norm(vec_B)  # Normalize the state vector
state_B = Statevector(vec_B)

print("state_A", state_A)
print("state_B", state_B)

F_A_B = np.abs(np.vdot(vec_A, vec_B))**2

shadow_finder_A = ShadowFinder(state_A, snapshot_count=10)
shadow_finder_B = ShadowFinder(state_B, snapshot_count=10)

shadow_finder_A.find_shadows()
shadow_finder_B.find_shadows()

# observable = []
# for i in range(n_qubit):
#     v_vecs = create_random_mat(4).reshape((2, 2))
#     v_vecs /= np.linalg.norm(v_vecs, axis=1) #FIXME: axis?
#     s = np.random.uniform(0, 1, 2)
#     s /= np.sum(s)
#     # print(s)
#     print(np.diag(s))
#     # print(v_vecs)
#     block = v_vecs.T.conj() @ np.diag(s) @ v_vecs
#     observable.append(block)

observable = estimate_observable(shadow_finder_A, shadow_finder_B, max_iters=100)

avg_A, estimates_A = shadow_finder_A.get_observation_average(observable)
avg_B, estimates_B = shadow_finder_B.get_observation_average(observable)

print(f"Observable:")
print(*observable, sep="\n--------\n")
print(f"State A: Average estimate of observable: {avg_A}")
print(f"real fidelity: {real_fidelity(state_A, observable)}")
# print(f"Samples for State A: {estimates_A}")

print(f"State B: Average estimate of observable: {avg_B}")
print(f"real fidelity: {real_fidelity(state_B, observable)}")
# print(f"Samples for State B: {estimates_B}")

print(f"""
We need to have\t(F(A, O))^2\t+\t(F(O, B))^2\t- 1 <=\tF(A, B)
\t\t\t{np.round(avg_A**2, 2)}\t+\t{np.round(avg_B**2, 2)}\t\t- 1 <=\t{np.round(F_A_B, 2)}
\t\t\t{np.round(avg_A**2 + avg_B**2 - 1, 2)}\t\t\t\t<=\t{np.round(F_A_B, 2)}
""")

