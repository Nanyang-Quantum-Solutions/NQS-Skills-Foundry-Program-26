from qiskit import QuantumCircuit
import numpy as np
from tqdm import tqdm

PAULI_TRANSFORMERS = {
    'X': np.array([[1, 1], [1, -1]]) / np.sqrt(2), # Hadamard gate
    'Y': np.array([[1, 1], [1j, -1j]]) / np.sqrt(2), # S-dagger followed by Hadamard
    'Z': np.array([[1, 0], [0, 1]]) # Identity gate (no transformation)
}
PAULI_MATRICES = {
    'X': np.array([[0, 1], [1, 0]]),
    'Y': np.array([[0, -1j], [1j, 0]]),
    'Z': np.array([[1, 0], [0, -1]]),
    'I': np.array([[1, 0], [0, 1]])
}

def real_fidelity(A, B):
    a_mat = A.to_operator().data
    b_mat = B[0]
    for b in B[1:]:
        b_mat = np.kron(b_mat, b)
    
    return np.real(np.trace(a_mat @ b_mat))

class ShadowFinder:
    def __init__(self, initial_state, snapshot_count):
        self.n_qubit = initial_state.num_qubits
        self.initial_state = initial_state
        self.snapshot_count = snapshot_count
        self.snapshots = []
    
    def find_shadows(self):
        for i in tqdm(range(self.snapshot_count), desc="Finding Shadows"):
            measurement_basis = []
            qc = QuantumCircuit(len(self.initial_state))
            for q in range(self.n_qubit):
                # Randomly choose a measurement basis for each qubit
                basis = str(np.random.choice(['X', 'Y', 'Z']))
                measurement_basis.append(basis)
                if basis == 'X':
                    qc.h(q)  # Apply Hadamard for X-basis measurement
                elif basis == 'Y':
                    qc.sdg(q)  # Apply S-dagger for Y-basis measurement
                    qc.h(q)    # Then Hadamard for Y-basis measurement
                # No additional gates needed for Z-basis measurement

            final_measurement = str(self.initial_state.evolve(qc).measure()[0])
            Psi = []
            for s_basis, s_value in zip(measurement_basis, final_measurement):
                measurement_vec = np.array([[1, 0]]) if s_value == '0' else np.array([[0, 1]])
                psi = PAULI_TRANSFORMERS[s_basis] @ measurement_vec.T
                Psi.append(psi)

            self.snapshots.append((tuple(measurement_basis), final_measurement, tuple(Psi)))

            print(f"Snapshot {i+1}: Measurement basis: {measurement_basis}, Final measurement: {final_measurement}")
    
    def get_observation_average(self, observable):
        # for now we assume observable is a single Pauli string, e.g., 'XIZ'
        observable_estimates = []
        for snapshot in self.snapshots:
            measurement_basis, final_measurement, Psi = snapshot
            result = 1
            for o_mat, s_basis, s_value, psi in zip(observable, measurement_basis, final_measurement, Psi):
                # # compute <psi|O|psi> based on the measurement basis and final measurement
                # # result *= 3<psi|O|psi> - 1
                # print(f"o_mat: {o_mat}")
                # print(f"psi: {psi}")
                # print(f"o_mat @ psi: {o_mat @ psi}")
                # print(f"res: {np.vdot(psi, o_mat @ psi)}")
                result *= np.real(3*np.vdot(psi, o_mat @ psi) - 1)
                # print(f"result: {result}")
            observable_estimates.append(float(result))
        return np.mean(observable_estimates), observable_estimates
    
    def basic_observable(self):
        observable_estimates = []
        for qubit_idx in range(self.n_qubit):
            basis_snap_map = {'X': [], 'Y': [], 'Z': []}
            for snap_idx in range(self.snapshot_count):
                basis_snap_map[
                    self.snapshots[snap_idx][0][qubit_idx]
                ].append(snap_idx)
            prevalent_basis = sorted(basis_snap_map, key=lambda k: -len(basis_snap_map[k]))[0]
            coeff = np.array([0., 0.])
            for snap_idx in basis_snap_map[prevalent_basis]:
                coeff[int(self.snapshots[snap_idx][1][qubit_idx])] += 1
            coeff /= np.linalg.norm(coeff)
            psi_hat = coeff[0] * PAULI_TRANSFORMERS[prevalent_basis] @ np.array([[1], [0]]) + \
                        coeff[1] * PAULI_TRANSFORMERS[prevalent_basis] @ np.array([[0], [1]])
            o = psi_hat @ psi_hat.conj().T
            observable_estimates.append(o)

        return  observable_estimates


def estimate_observable(shadow_a, shadow_b, max_iters=20, lr=1e-1):
    # initial_value: linear combination of two basic_Os
    n_qubit = shadow_a.n_qubit
    snapshot_count = shadow_a.snapshot_count
    observable_A = shadow_a.basic_observable()
    observable_B = shadow_b.basic_observable()
    observable_elements = observable_A
    max_similarity = shadow_a.get_observation_average(observable_elements)[0]**2 + shadow_b.get_observation_average(observable_elements)[0]**2
    for alpha in np.linspace(.1, .9, 9):
        print(f"{'='*10} {alpha} {'='*10}")
        observable = []
        for o_elemA, o_elemB in zip(observable_A, observable_B):
            result = alpha*o_elemA + (1-alpha)*o_elemB
            s, _ = np.linalg.eig(result)
            if np.any(s<0):
                break
            else:
                result /= np.trace(result)
            observable.append(result)

        if len(observable) != n_qubit:
            continue

        avg_A, _ = shadow_a.get_observation_average(observable)
        avg_B, _ = shadow_b.get_observation_average(observable)
        similarity = avg_A**2 + avg_B**2
        if similarity > max_similarity:
            max_similarity = similarity
            observable_elements = observable

    est_fidelity_history = [max_similarity]
    real_fidelity_history = [
        real_fidelity(shadow_a.initial_state, observable_elements) + real_fidelity(shadow_b.initial_state, observable_elements)
    ]

    # gradient_descend
    for _ in tqdm(range(max_iters), desc="finding a nearby unentangled density matrix"):
        # Fill-up trace values - as a mean for gradient
        trace_values_a = np.zeros((snapshot_count, n_qubit))
        trace_values_b = np.zeros((snapshot_count, n_qubit))
        for snap_idx, (snapshot_a, snapshot_b) in enumerate(zip(shadow_a.snapshots, shadow_b.snapshots)):
            measurement_basis_a, final_measurement_a, Psi_a = snapshot_a
            measurement_basis_b, final_measurement_b, Psi_b = snapshot_b
            for qubit_idx, (psi_a, psi_b) in enumerate(zip(Psi_a, Psi_b)):
                o_mat = observable_elements[qubit_idx]
                trace_values_a[snap_idx, qubit_idx] = np.real(3*np.vdot(psi_a, o_mat @ psi_a) - 1)
                trace_values_b[snap_idx, qubit_idx] = np.real(3*np.vdot(psi_b, o_mat @ psi_b) - 1)
        
        similarity_a = np.mean(np.prod(trace_values_a, axis=1))
        similarity_b = np.mean(np.prod(trace_values_b, axis=1))
                
        for qubit_idx in range(n_qubit):
            df_do_a = np.zeros((2,2), dtype=np.complex128)
            df_do_b = np.zeros((2,2), dtype=np.complex128)
            for snap_idx in range(snapshot_count):
                psi_a = shadow_a.snapshots[snap_idx][2][qubit_idx]
                psi_b = shadow_b.snapshots[snap_idx][2][qubit_idx]
                PsiisP_a = psi_a @ psi_a.conj().T
                PsiisP_b = psi_b @ psi_b.conj().T
                df_do_j_a = 3 * np.prod(trace_values_a[snap_idx, :qubit_idx]) * np.prod(trace_values_a[snap_idx, qubit_idx+1:]) * PsiisP_a
                df_do_j_b = 3 * np.prod(trace_values_b[snap_idx, :qubit_idx]) * np.prod(trace_values_b[snap_idx, qubit_idx+1:]) * PsiisP_b
                df_do_a += df_do_j_a
                df_do_b += df_do_j_b
            
            # gradient descend
            df_do = similarity_a * df_do_a + similarity_b * df_do_b
            df_do = df_do/np.abs(np.trace(df_do))
            new_o = observable_elements[qubit_idx] - lr*df_do

            # O should be PSD
            v, _ = np.linalg.eig(new_o)
            v = np.real(v)
            
            # trace should be 1
            new_o = new_o / np.trace(new_o)

            if np.any(v<0):
                1
                # print(f"{'='*20} negative v, skip {'='*20}")
                # print(observable_elements[qubit_idx])
                # print(df_do)
                # print("v:", v)
                # print("update:")
                # print(- lr * df_do)
            else:
                # print("update:")
                # print(- lr * df_do)
                observable_elements[qubit_idx] = new_o
                sim_a = shadow_a.get_observation_average(observable_elements)[0]
                real_a = real_fidelity(shadow_a.initial_state, observable_elements)
                sim_b = shadow_b.get_observation_average(observable_elements)[0]
                real_b = real_fidelity(shadow_b.initial_state, observable_elements)
                est_fidelity_history.append(sim_a**2 + sim_b**2)
                real_fidelity_history.append(real_a**2 + real_b**2)
    
    print("est_fidelity_history:", np.array(est_fidelity_history))
    print("real_fidelity_history:", np.array(real_fidelity_history))

    return observable_elements

